/*
 * blktrace output analysis: generate a timeline & gather statistics
 *
 * Copyright (C) 2022 Andrew Zhu <mrju.email@gmail.com>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include "globals.h"

#define BLK_TA_MASK (((1 << BLK_TC_SHIFT) - 1) & ~__BLK_TA_CGROUP)

#define __scan_depth_end(t, end, depth) \
		min(((void *) (unsigned long) t + sizeof(t) * depth), end)

#define __trace_size(t) (sizeof(*t) + t->pdu_len)

#define __next_trace(t) \
		((typeof(t)) ((unsigned long) t + __trace_size(t)))

#define for_each_trace(t, start, end) \
		for (t = start; (void *) t < end; t = __next_trace(t))

#define dbg_print(t)                                        \
	printf("magic:0x%x sequence:%u time:%lld "          \
			"sector:%lld bytes:%u action:0x%x " \
			"pid:%u device:0x%x cpu:%u "        \
			"err:%hd pdu_len:%hd\n",            \
			t->magic, t->sequence, t->time,     \
			t->sector, t->bytes, t->action,     \
			t->pid, t->device, t->cpu,          \
			t->error, t->pdu_len);

int do_x2q(const char *name)
{
	int fd, ret;
	struct stat buf;
#if 0
	uint64_t total_bytes;
#endif
	unsigned long depth = 512;
	struct blk_io_trace *t, *__t;
	void *start;

	fd = open(name, O_RDWR);
	if (fd < 0) {
		fprintf(stderr, "open %s failed.\n", name);
		ret = fd;
		goto err0;
	}

	ret = fstat(fd, &buf);
	if (ret < 0) {
		fprintf(stderr, "fstat %s failed.\n", name);
		goto err1;
	}

	start = mmap(NULL, buf.st_size,
			PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
	if (start == MAP_FAILED) {
		fprintf(stderr, "mmap failed.\n");
		ret = -ENOMEM;
		goto err1;
	}

	for_each_trace(t, start, start + buf.st_size) {
		switch (t->action & BLK_TA_MASK) {
		case __BLK_TA_QUEUE:
			for_each_trace(__t, __next_trace(t),
					__scan_depth_end(t, start + buf.st_size, depth)) {
				if ((__t->action & BLK_TA_MASK) == __BLK_TA_SPLIT
						&& (t->sector == __t->sector)) {
					t->sector = t->sector + (__t->bytes >> 9);
					t->bytes = t->bytes - __t->bytes;
#if 0
					total_bytes = t->bytes;
					t->bytes = __t->bytes;
					__t->sector = __t->sector + (__t->bytes >> 9);
					__t->bytes = total_bytes - t->bytes;
#endif
					__t->action &= ~BLK_TA_MASK;
					__t->action |= __BLK_TA_QUEUE;
					dbg_print(__t);
#if 0
					printf("seq:%d t->sector:%llu t->byes:%u __t->sector:%llu __t->byes:%u\n",
							t->sequence, t->sector, t->bytes, __t->sector, __t->bytes);
#endif
					break;
				}
			}

			break;
		case __BLK_TA_SPLIT:
		case __BLK_TA_REMAP:
		case __BLK_TA_INSERT:
		case __BLK_TA_GETRQ:
		case __BLK_TA_BACKMERGE:
		case __BLK_TA_FRONTMERGE:
		case __BLK_TA_REQUEUE:
		case __BLK_TA_ISSUE:
		case __BLK_TA_COMPLETE:
		case __BLK_TA_PLUG:
		case __BLK_TA_UNPLUG_IO:
		case __BLK_TA_UNPLUG_TIMER:
		case __BLK_TA_SLEEPRQ:
		default:
			/* add debug info */
			break;
		}
	}

	munmap(start, (size_t) (start + buf.st_size));
	close(fd);

	return 0;

err1:
	close(fd);

err0:
	return ret;
}
