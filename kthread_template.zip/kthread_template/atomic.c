/*
 * Copyright (C) 2019 Andrew <mrju.email@gmail.com>
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the Free
 * Software Foundation; either version 2 of the License, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
 */

#include <linux/module.h>
#include <linux/kthread.h>
#include <linux/delay.h>
#include <linux/platform_device.h>
#include <linux/genhd.h>
#include <linux/bio.h>
#include <linux/fs.h>
#include <linux/of.h>

#define STR(x) _STR(x)
#define _STR(x) #x

#define VERSION_PREFIX atomic
#define MAJOR_VERSION 1
#define MINOR_VERSION 0
#define PATCH_VERSION 0
#define VERSION STR(VERSION_PREFIX-MAJOR_VERSION.MINOR_VERSION.PATCH_VERSION)
#define DEVICE_NAME "atomic"

#define NR_TASKS 1
#define KTHREAD_NAME "atomic-task"
#define INTERVAL_IN_MSECS 3000

struct task_info {
	char *name;
	int id;
	int (*func)(void *);
	struct task_struct *task;
};

static int task_func(void *data)
{
	struct task_info *task_info = data;
	struct bio *bio;
	struct file_system_type *fs_type;
	struct block_device *bdev;

	// blkdev_get_by_path
	// blkdev_get_by_dev
	fs_type = get_fs_type("ext4");
	pr_info("andrew foo: %s %d fs_type:0x%px fs_type->name:%s\n",
			__func__, __LINE__, fs_type, fs_type->name);

	bdev = blkdev_get_by_path("/dev/vda", 131,fs_type);
	if (IS_ERR(bdev))
		return PTR_ERR(bdev);

	pr_info("andrew foo: %s %d bdev:0x%px bdev->bd_disk->disk_name:%s\n",
			__func__, __LINE__, bdev, bdev->bd_disk->disk_name);

	bio = bio_alloc(GFP_NOIO, 1);
	if (!bio)
		return -ENOMEM;

	// submit_bio(bio);

	while (!kthread_should_stop()) {
		printk("%s(): name:%s cpu:%d id:%d\n",
				__func__,
				task_info->name,
				smp_processor_id(),
				task_info->id);

		msleep(INTERVAL_IN_MSECS);
	}

	return 0;
}

static int atomic_probe(struct platform_device *pdev)
{
	int i, ret;
	struct task_info *task_info, *info;

	task_info = devm_kzalloc(&pdev->dev,
			sizeof(*task_info) * NR_TASKS,
			GFP_KERNEL);
	if (!task_info)
		return -ENOMEM;

	for (i = 0, info = task_info;
			i < NR_TASKS; i++, info++) {
		info->name = KTHREAD_NAME;
		info->id = i;
		info->func = task_func;
		info->task = kthread_create(info->func,
				(void *)info, info->name);
		if (IS_ERR(info->task)) {
			ret = PTR_ERR(info->task);
			goto err;
		}

		kthread_bind(info->task, 3);
		wake_up_process(info->task);
	}

	platform_set_drvdata(pdev, task_info);

	return 0;

err:
	for (info--; i > 0; i--, info--)
		kthread_stop(info->task);

	return ret;
}

static int atomic_remove(struct platform_device *pdev)
{
	int i;
	struct task_info *task_info, *info;

	task_info = platform_get_drvdata(pdev);

	for (i = 0, info = task_info;
			i < NR_TASKS; i++, info++)
		kthread_stop(info->task);

	devm_kfree(&pdev->dev, task_info);

	return 0;
}

static struct platform_driver atomic_drv = {
	.probe	= atomic_probe,
	.remove	= atomic_remove,
	.driver	= {
		.owner = THIS_MODULE,
		.name = DEVICE_NAME,
	}
};

static int __init atomic_init(void)
{
	int ret;
	struct platform_device *pdev;

	pdev = platform_device_register_simple(DEVICE_NAME, -1, NULL, 0);
	if (IS_ERR(pdev))
		return PTR_ERR(pdev);

	ret = platform_driver_register(&atomic_drv);
	if (ret) {
		platform_device_unregister(pdev);
		return ret;
	}

	return 0;
}

static void __exit atomic_exit(void)
{
	struct device *dev;

	dev = bus_find_device_by_name(atomic_drv.driver.bus, NULL, DEVICE_NAME);
	if (dev)
		platform_device_unregister(to_platform_device(dev));

	platform_driver_unregister(&atomic_drv);
}

module_init(atomic_init);
module_exit(atomic_exit);

MODULE_ALIAS("atomic-driver");
MODULE_LICENSE("GPL");
MODULE_VERSION(VERSION);
MODULE_DESCRIPTION("Linux is not Unix");
MODULE_AUTHOR("andrew, mrju.email@gmail.com");
