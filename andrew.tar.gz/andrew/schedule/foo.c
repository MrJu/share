/*
 * Copyright (C) 2019 Andrew <mrju.email@gmail.com>
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the Free
 * Software Foundation; either version 2 of the License, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
 */

#include <linux/module.h>
#include <linux/cdev.h>
#include <linux/slab.h>
#include <linux/delay.h>
#include <linux/fs.h>
#include <linux/uaccess.h>

#define STR(x) _STR(x)
#define _STR(x) #x

#define VERSION_PREFIX Foo
#define MAJOR_VERSION 1
#define MINOR_VERSION 0
#define PATCH_VERSION 0

#define VERSION STR(VERSION_PREFIX-MAJOR_VERSION.MINOR_VERSION.PATCH_VERSION)

#define BASE_MINOR 0
#define MINOR_NUM 8
#define CLASS_NAME "foo"
#define DEVICE_NAME_PREFIX "foo"
#define DEVS_NANE "foo"

#define READ_INTERVAL_IN_MSEC 1000

struct foo_device {
	dev_t devno;
	struct cdev *cdev;
	struct class *class;
	struct device *device;
	struct rw_semaphore rwsem;
	unsigned long timeout;
};

static struct foo_device *foo;

static int foo_open(struct inode *inode, struct file *filp)
{
	int minor;

	minor = iminor(file_inode(filp));

	printk("%s(): %s%d\n", __func__, DEVICE_NAME_PREFIX, minor);

	return 0;
}

static int foo_release(struct inode *inode, struct file *filp)
{
	int minor;

	minor = iminor(file_inode(filp));

	printk("%s(): %s%d\n", __func__, DEVICE_NAME_PREFIX, minor);

	return 0;
}

static ssize_t foo_read(struct file *filp, char __user *buf,
			size_t size, loff_t * offset)
{
	int minor, i;
	unsigned long timeout = foo->timeout;

	minor = iminor(file_inode(filp));

	switch (minor) {
	case 0:
		for (i = 0; i < timeout; i++) {
			if (!foo->timeout)
				break;
			printk("%s(): %s%d loop %d\n",
					__func__, DEVICE_NAME_PREFIX, minor, i);
			schedule();
			msleep(READ_INTERVAL_IN_MSEC);
		}
		break;
	case 1:
	case 2:
	case 3:
	case 4:
	case 5:
	case 6:
	case 7:
	default:
		for (i = 0; i < timeout; i++) {
			if (!foo->timeout)
				break;
			printk("%s(): %s%d loop %d\n",
					__func__, DEVICE_NAME_PREFIX, minor, i);
			msleep(READ_INTERVAL_IN_MSEC);
		}
		break;
	}

	return 0;
}

static ssize_t foo_write(struct file *filp, const char __user * buf,
			size_t size, loff_t * offset)
{
	int minor, ret;
	unsigned long timeout;
	size_t __size;
	char __buf[32];

	minor = iminor(file_inode(filp));
	__size = min(size, (size_t) 32);

	switch (minor) {
	case 0:
		ret = copy_from_user(__buf, buf, __size);
		if (ret)
			return ret;

		__buf[__size -1] = '\0';
		ret = kstrtoul(__buf, 10, &timeout);
		if (ret < 0)
			return ret;

		foo->timeout = timeout;
		printk("%s(): %s%d set timeout %lu\n",
				__func__, DEVICE_NAME_PREFIX, minor, foo->timeout);
		break;
	case 1:
	case 2:
	case 3:
	case 4:
	case 5:
	case 6:
	case 7:
	default:
		break;
	}

	printk("%s(): %s%d\n", __func__, DEVICE_NAME_PREFIX, minor);

	return __size;
}

static struct file_operations foo_fops = {
	.owner = THIS_MODULE,
	.open = foo_open,
	.read = foo_read,
	.write = foo_write,
	.release = foo_release,
};


static int __init foo_init(void)
{
	int index, ret;

	printk("%s(): %d\n", __func__, __LINE__);

	foo = kzalloc(sizeof(*foo), GFP_KERNEL);
	if (!foo) {
		ret = -ENOMEM;
		goto err_device_alloc;
	}

	init_rwsem(&foo->rwsem);
	foo->timeout = 0;

	ret = alloc_chrdev_region(&foo->devno,
			BASE_MINOR, MINOR_NUM, DEVS_NANE);
	if (ret < 0)
		goto err_alloc_chrdev;

	foo->cdev = cdev_alloc();
	if (!foo->cdev) {
		ret = -ENOMEM;
		goto err_cdev_alloc;
	}

	cdev_init(foo->cdev, &foo_fops);

	ret = cdev_add(foo->cdev, foo->devno, MINOR_NUM);
	if (ret)
		goto err_cdev_add;

	foo->class = class_create(THIS_MODULE, CLASS_NAME);
	if (IS_ERR(foo->class)) {
		ret = PTR_ERR(foo->class);
		goto err_cdev_add;
	}

	for (index = 0; index < MINOR_NUM; index++) {
		foo->device = device_create(foo->class, NULL,
		                MKDEV(MAJOR(foo->devno), BASE_MINOR + index),
		                NULL, DEVICE_NAME_PREFIX"%d", index);

		if (IS_ERR(foo->device)) {
			ret = PTR_ERR(foo->device);
			goto err_device_create;
		}
	}

	return 0;

err_device_create:
	for (index--; index >= 0; index--) {
		device_destroy(foo->class,
				MKDEV(MAJOR(foo->devno),
				BASE_MINOR + index));
	}

	class_destroy(foo->class);

err_cdev_add:
	cdev_del(foo->cdev);

err_cdev_alloc:
	unregister_chrdev_region(foo->devno, MINOR_NUM);

err_alloc_chrdev:
	kfree(foo);

err_device_alloc:
	return ret;
}

static void __exit foo_exit(void)
{
	int index;

	printk("%s(): %d\n", __func__, __LINE__);

	for (index = 0; index < MINOR_NUM; index++) {
		device_destroy(foo->class,
				MKDEV(MAJOR(foo->devno),
				BASE_MINOR + index));
	}

	class_destroy(foo->class);
	cdev_del(foo->cdev);
	unregister_chrdev_region(foo->devno, MINOR_NUM);
	kfree(foo);
}

module_init(foo_init);
module_exit(foo_exit);

MODULE_ALIAS("foo-driver");
MODULE_LICENSE("GPL");
MODULE_VERSION(VERSION);
MODULE_DESCRIPTION("Linux is not Unix");
MODULE_AUTHOR("andrew, mrju.email@gmail.com");
